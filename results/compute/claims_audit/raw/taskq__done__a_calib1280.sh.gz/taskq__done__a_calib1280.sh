#!/bin/bash
export HF_HOME=/scratch/09032/saini_2/tmp/hf TORCH_HOME=/scratch/09032/saini_2/tmp/torch HF_HUB_OFFLINE=1 XDG_CACHE_HOME=/scratch/09032/saini_2/tmp/cache TRITON_CACHE_DIR=/scratch/09032/saini_2/tmp/triton OMP_NUM_THREADS=8
cd /scratch/09032/saini_2/sca/code/041bbf1
/work/09032/saini_2/vista/library/uv-envs/sca/bin/python scripts/calibrate.py --count 16 --res 1280x1280 --scales 2 --guidance 4.5 --out /scratch/09032/saini_2/sca/calib/k1_1280b.npz --transfer-with /scratch/09032/saini_2/sca/calib/k1_1024.npz
