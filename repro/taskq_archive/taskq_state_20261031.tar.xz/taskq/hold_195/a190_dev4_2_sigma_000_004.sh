#!/bin/bash
# SCA_MIN_SECONDS=1500
# 195-protocol wrapper (SigMa dev-matched, Aesthetic-4K rows 0-3): runs the clone in hold_195/body (only prompts file, start/end and out root differ from
# the done template; out root baseline_expansion_20261017_dev4 is fresh). A CUDA OOM from co-tenant GPU processes is a retry:
# the task republishes itself to pending (at most 30 times) and exits 75. Other failures keep their exit code.
set -uo pipefail
Q=/scratch/09032/saini_2/sca/taskq; NAME=a190_dev4_2_sigma_000_004.sh; B=/scratch/09032/saini_2/sca/taskq/hold_195/body/a190_dev4_2_sigma_000_004.body.sh; LOGF=/scratch/09032/saini_2/sca/taskq/hold_195/body/a190_dev4_2_sigma_000_004.attempt.log
oom_requeue(){ grep -q -E 'OutOfMemoryError|CUDA out of memory|CUDA error: out of memory|cudaErrorMemoryAllocation' "$LOGF" || return 1
  n=$(( $(cat $Q/hold_195/retries/$NAME 2>/dev/null || echo 0) + 1 )); echo $n > $Q/hold_195/retries/$NAME
  if [ $n -gt 30 ]; then echo "CUDA OOM retry limit reached (attempt $n); not requeued"; return 1; fi
  cp "$0" "$Q/pending/.$NAME.tmp.$$" && mv -f "$Q/pending/.$NAME.tmp.$$" "$Q/pending/$NAME" && echo "CUDA OOM from co-tenant GPU processes: requeued $NAME to pending (attempt $n)"; }
recovered(){ if [ -e "$Q/failed/$NAME" ]; then mkdir -p $Q/recovered/a195_oom; mv "$Q/failed/$NAME" "$Q/recovered/a195_oom/$NAME.$(date +%Y%m%dT%H%M%S)"; fi; }
bash "$B" 2>&1 | tee "$LOGF"; rc=${PIPESTATUS[0]}
if [ $rc -ne 0 ]; then oom_requeue && exit 75; exit $rc; fi
recovered
exit 0
