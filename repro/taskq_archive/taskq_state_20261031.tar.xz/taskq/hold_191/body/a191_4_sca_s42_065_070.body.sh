#!/bin/bash
export HF_HOME=/scratch/09032/saini_2/tmp/hf TORCH_HOME=/scratch/09032/saini_2/tmp/torch HF_HUB_OFFLINE=1 XDG_CACHE_HOME=/scratch/09032/saini_2/tmp/cache TRITON_CACHE_DIR=/scratch/09032/saini_2/tmp/triton OMP_NUM_THREADS=8
cd /scratch/09032/saini_2/sca/code/PHASE2
/work/09032/saini_2/vista/library/uv-envs/sca/bin/python scripts/sample.py --method sca --res 4096x4096 --prompts /scratch/09032/saini_2/constancy_rope/prompts/aesthetic4k_eval.jsonl --start 65 --end 70 --seed 0 --guidance 4.5 --out /scratch/09032/saini_2/sca/out/budget/sca_s42/4096x4096 --pi-table /scratch/09032/saini_2/sca/calib/k1_1024.npz --gate-sigma 0.89 --steps 42 --label sca_s42
