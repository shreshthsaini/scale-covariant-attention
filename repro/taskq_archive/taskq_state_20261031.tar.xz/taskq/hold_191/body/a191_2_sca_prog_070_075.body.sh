#!/bin/bash
# SCA_MIN_SECONDS=1500
# Progressive SCA generation, aesthetic4k_eval prompts [70, 75) at 4096x4096, label sca_prog (resumable, per-prompt seeds).
set -euo pipefail
export HF_HOME=/scratch/09032/saini_2/tmp/hf TORCH_HOME=/scratch/09032/saini_2/tmp/torch HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 XDG_CACHE_HOME=/scratch/09032/saini_2/tmp/cache TRITON_CACHE_DIR=/scratch/09032/saini_2/tmp/triton OMP_NUM_THREADS=8
export WANDB_PROJECT=scale-covariant-attention WANDB_DIR=/scratch/09032/saini_2/sca/wandb PYTHONDONTWRITEBYTECODE=1
export CC=/usr/bin/gcc CXX=/usr/bin/g++
cd /scratch/09032/saini_2/sca/code/PROG
"$CC" --version | head -n 1
/work/09032/saini_2/vista/library/uv-envs/sca/bin/python scripts/sample_progressive.py --prompts /scratch/09032/saini_2/constancy_rope/prompts/aesthetic4k_eval.jsonl --seed 0 --out /scratch/09032/saini_2/sca/out/prog/sca_prog/4096x4096 --pi-table /scratch/09032/saini_2/sca/calib/k1_1024.npz --gate-sigma 0.89 --label sca_prog --start 70 --end 75 --wandb
/work/09032/saini_2/vista/library/uv-envs/sca/bin/python scripts/sample_progressive.py --prompts /scratch/09032/saini_2/constancy_rope/prompts/aesthetic4k_eval.jsonl --seed 0 --out /scratch/09032/saini_2/sca/out/prog/sca_prog/4096x4096 --pi-table /scratch/09032/saini_2/sca/calib/k1_1024.npz --gate-sigma 0.89 --label sca_prog --start 70 --end 75 --check
