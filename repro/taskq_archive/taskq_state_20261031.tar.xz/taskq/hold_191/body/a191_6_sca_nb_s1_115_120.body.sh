#!/bin/bash
# E5: SCA final, seed 1
export HF_HOME=/scratch/09032/saini_2/tmp/hf TORCH_HOME=/scratch/09032/saini_2/tmp/torch HF_HUB_OFFLINE=1 XDG_CACHE_HOME=/scratch/09032/saini_2/tmp/cache TRITON_CACHE_DIR=/scratch/09032/saini_2/tmp/triton OMP_NUM_THREADS=8
unset CROPE_TRANSFORMER CROPE_ROPE
cd /scratch/09032/saini_2/sca/code/2d11740
/work/09032/saini_2/vista/library/uv-envs/sca/bin/python scripts/sample.py --method sca --seed 1 --guidance 4.5 --out /scratch/09032/saini_2/sca/out/seed1/sca_nb/4096x4096 --pi-table /scratch/09032/saini_2/sca/calib/k1_1024.npz --gate-sigma 0.89 --label sca_nb --res 4096x4096 --prompts /scratch/09032/saini_2/constancy_rope/prompts/aesthetic4k_eval.jsonl --start 115 --end 120
