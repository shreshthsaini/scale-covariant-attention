#!/bin/bash
# duplication-fix rerun s2: dupfix_bridge --bridge-cells 8 --bridge-k 16
export HF_HOME=/scratch/09032/saini_2/tmp/hf TORCH_HOME=/scratch/09032/saini_2/tmp/torch HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 XDG_CACHE_HOME=/scratch/09032/saini_2/tmp/cache TRITON_CACHE_DIR=/scratch/09032/saini_2/tmp/triton OMP_NUM_THREADS=8
unset CROPE_TRANSFORMER CROPE_ROPE
cd /scratch/09032/saini_2/sca/code/bd42387
/work/09032/saini_2/vista/library/uv-envs/sca/bin/python scripts/sample.py --method sca --seed 2 --guidance 4.5 --res 4096x4096 --gate-sigma 0.89 --out /scratch/09032/saini_2/sca/out/dupfix_seed2/dupfix_bridge/4096x4096 --prompts /scratch/09032/saini_2/constancy_rope/prompts/aesthetic4k_eval.jsonl --start 90 --end 95 --pi-table /scratch/09032/saini_2/sca/calib/k1_1024.npz --label dupfix_bridge --bridge-cells 8 --bridge-k 16
