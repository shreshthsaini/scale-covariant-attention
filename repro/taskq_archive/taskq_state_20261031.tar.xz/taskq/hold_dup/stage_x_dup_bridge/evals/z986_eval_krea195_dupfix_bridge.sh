#!/bin/bash
# Duplication-fix rerun, row kr (krea195): dupfix_bridge_krea vs sca_krea and AReA; clone of taskq/done/a000_z960_eval_a4k195_main.sh
# (same metric commands, corrected patch FID for Aesthetic-4K rows, paired bootstrap 2000 draws) plus the duplicate detector.
export HF_HOME=/scratch/09032/saini_2/tmp/hf TORCH_HOME=/scratch/09032/saini_2/tmp/torch HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 XDG_CACHE_HOME=/scratch/09032/saini_2/tmp/cache TRITON_CACHE_DIR=/scratch/09032/saini_2/tmp/triton OMP_NUM_THREADS=8
unset CROPE_TRANSFORMER CROPE_ROPE
set -uo pipefail
Q=/scratch/09032/saini_2/sca/taskq; E=/scratch/09032/saini_2/sca/eval/krea195_dupfix_bridge; R=/work/09032/saini_2/vista/Projects/Exploration/Scale_Covariant_Attention/results/krea195_dupfix_bridge
# RELEASE_AFTER: ^(x_d96_kr_dupfix_bridge_0000_0005|x_d96_kr_dupfix_bridge_0005_0010|x_d96_kr_dupfix_bridge_0010_0015|x_d96_kr_dupfix_bridge_0015_0020|x_d96_kr_dupfix_bridge_0020_0025|x_d96_kr_dupfix_bridge_0025_0030|x_d96_kr_dupfix_bridge_0030_0035|x_d96_kr_dupfix_bridge_0035_0040|x_d96_kr_dupfix_bridge_0040_0045|x_d96_kr_dupfix_bridge_0045_0050|x_d96_kr_dupfix_bridge_0050_0055|x_d96_kr_dupfix_bridge_0055_0060|x_d96_kr_dupfix_bridge_0060_0065|x_d96_kr_dupfix_bridge_0065_0070|x_d96_kr_dupfix_bridge_0070_0075|x_d96_kr_dupfix_bridge_0075_0080|x_d96_kr_dupfix_bridge_0080_0085|x_d96_kr_dupfix_bridge_0085_0090|x_d96_kr_dupfix_bridge_0090_0095|x_d96_kr_dupfix_bridge_0095_0100|x_d96_kr_dupfix_bridge_0100_0105|x_d96_kr_dupfix_bridge_0105_0110|x_d96_kr_dupfix_bridge_0110_0115|x_d96_kr_dupfix_bridge_0115_0120|x_d96_kr_dupfix_bridge_0120_0125|x_d96_kr_dupfix_bridge_0125_0130|x_d96_kr_dupfix_bridge_0130_0135|x_d96_kr_dupfix_bridge_0135_0140|x_d96_kr_dupfix_bridge_0140_0145|x_d96_kr_dupfix_bridge_0145_0150|x_d96_kr_dupfix_bridge_0150_0155|x_d96_kr_dupfix_bridge_0155_0160|x_d96_kr_dupfix_bridge_0160_0165|x_d96_kr_dupfix_bridge_0165_0170|x_d96_kr_dupfix_bridge_0170_0175|x_d96_kr_dupfix_bridge_0175_0180|x_d96_kr_dupfix_bridge_0180_0185|x_d96_kr_dupfix_bridge_0185_0190|x_d96_kr_dupfix_bridge_0190_0195)[.]sh
NAME=z986_eval_krea195_dupfix_bridge.sh; HOLD=/scratch/09032/saini_2/sca/taskq/hold_dup_eval
if ls $Q/pending $Q/running 2>/dev/null | grep -q -E '^(x_d96_kr_dupfix_bridge_0000_0005|x_d96_kr_dupfix_bridge_0005_0010|x_d96_kr_dupfix_bridge_0010_0015|x_d96_kr_dupfix_bridge_0015_0020|x_d96_kr_dupfix_bridge_0020_0025|x_d96_kr_dupfix_bridge_0025_0030|x_d96_kr_dupfix_bridge_0030_0035|x_d96_kr_dupfix_bridge_0035_0040|x_d96_kr_dupfix_bridge_0040_0045|x_d96_kr_dupfix_bridge_0045_0050|x_d96_kr_dupfix_bridge_0050_0055|x_d96_kr_dupfix_bridge_0055_0060|x_d96_kr_dupfix_bridge_0060_0065|x_d96_kr_dupfix_bridge_0065_0070|x_d96_kr_dupfix_bridge_0070_0075|x_d96_kr_dupfix_bridge_0075_0080|x_d96_kr_dupfix_bridge_0080_0085|x_d96_kr_dupfix_bridge_0085_0090|x_d96_kr_dupfix_bridge_0090_0095|x_d96_kr_dupfix_bridge_0095_0100|x_d96_kr_dupfix_bridge_0100_0105|x_d96_kr_dupfix_bridge_0105_0110|x_d96_kr_dupfix_bridge_0110_0115|x_d96_kr_dupfix_bridge_0115_0120|x_d96_kr_dupfix_bridge_0120_0125|x_d96_kr_dupfix_bridge_0125_0130|x_d96_kr_dupfix_bridge_0130_0135|x_d96_kr_dupfix_bridge_0135_0140|x_d96_kr_dupfix_bridge_0140_0145|x_d96_kr_dupfix_bridge_0145_0150|x_d96_kr_dupfix_bridge_0150_0155|x_d96_kr_dupfix_bridge_0155_0160|x_d96_kr_dupfix_bridge_0160_0165|x_d96_kr_dupfix_bridge_0165_0170|x_d96_kr_dupfix_bridge_0170_0175|x_d96_kr_dupfix_bridge_0175_0180|x_d96_kr_dupfix_bridge_0180_0185|x_d96_kr_dupfix_bridge_0185_0190|x_d96_kr_dupfix_bridge_0190_0195)[.]sh'; then mkdir -p $HOLD; cp "$0" $HOLD/.$NAME.tmp.$$ && mv -f $HOLD/.$NAME.tmp.$$ $HOLD/$NAME; echo "parked $NAME: generation still pending or running"; exit 3; fi
if ls $Q/failed 2>/dev/null | grep -q -E '^(x_d96_kr_dupfix_bridge_0000_0005|x_d96_kr_dupfix_bridge_0005_0010|x_d96_kr_dupfix_bridge_0010_0015|x_d96_kr_dupfix_bridge_0015_0020|x_d96_kr_dupfix_bridge_0020_0025|x_d96_kr_dupfix_bridge_0025_0030|x_d96_kr_dupfix_bridge_0030_0035|x_d96_kr_dupfix_bridge_0035_0040|x_d96_kr_dupfix_bridge_0040_0045|x_d96_kr_dupfix_bridge_0045_0050|x_d96_kr_dupfix_bridge_0050_0055|x_d96_kr_dupfix_bridge_0055_0060|x_d96_kr_dupfix_bridge_0060_0065|x_d96_kr_dupfix_bridge_0065_0070|x_d96_kr_dupfix_bridge_0070_0075|x_d96_kr_dupfix_bridge_0075_0080|x_d96_kr_dupfix_bridge_0080_0085|x_d96_kr_dupfix_bridge_0085_0090|x_d96_kr_dupfix_bridge_0090_0095|x_d96_kr_dupfix_bridge_0095_0100|x_d96_kr_dupfix_bridge_0100_0105|x_d96_kr_dupfix_bridge_0105_0110|x_d96_kr_dupfix_bridge_0110_0115|x_d96_kr_dupfix_bridge_0115_0120|x_d96_kr_dupfix_bridge_0120_0125|x_d96_kr_dupfix_bridge_0125_0130|x_d96_kr_dupfix_bridge_0130_0135|x_d96_kr_dupfix_bridge_0135_0140|x_d96_kr_dupfix_bridge_0140_0145|x_d96_kr_dupfix_bridge_0145_0150|x_d96_kr_dupfix_bridge_0150_0155|x_d96_kr_dupfix_bridge_0155_0160|x_d96_kr_dupfix_bridge_0160_0165|x_d96_kr_dupfix_bridge_0165_0170|x_d96_kr_dupfix_bridge_0170_0175|x_d96_kr_dupfix_bridge_0175_0180|x_d96_kr_dupfix_bridge_0180_0185|x_d96_kr_dupfix_bridge_0185_0190|x_d96_kr_dupfix_bridge_0190_0195)[.]sh'; then echo "generation task failed; not evaluating"; exit 3; fi
if [ -e $E/DONE ]; then echo "already complete: $E"; exit 0; fi
[ -e $E ] && mv $E $E.partial_$(date +%Y%m%dT%H%M%S)
mkdir -p $E/paired $R
run(){ "$@" 2>&1 | tee -a $E/run.log; local rc=${PIPESTATUS[0]}; if [ $rc -ne 0 ]; then echo "step failed rc=$rc: $*"; exit $rc; fi; }
/work/09032/saini_2/vista/library/uv-envs/sca/bin/python -I - "/scratch/09032/saini_2/constancy_rope/prompts/aesthetic4k_eval.jsonl" "dupfix_bridge_krea|0|/scratch/09032/saini_2/sca/out/dupfix_krea/dupfix_bridge_krea/4096x4096;sca_krea|0|/scratch/09032/saini_2/sca/out/krea/sca_krea/4096x4096;area|0|/scratch/09032/saini_2/sca/out/krea/area/4096x4096" "4096x4096" "$E/root" <<'PYEOF'
import glob, json, os, sys
prompts, spec, res, link = sys.argv[1:5]
ids = [json.loads(l)["id"] for l in open(prompts) if l.strip()]
bad = 0
for item in spec.split(";"):
    method, seed, dirs = item.split("|")
    n = 0
    for i in ids:
        pngs = [p for d in dirs.split(",") for p in glob.glob(f"{d}/{glob.escape(i)}_*seed{seed}.png")]
        if len(pngs) != 1 or not json.load(open(pngs[0][:-4] + ".json")).get("complete"):
            bad += 1
            continue
        d = os.path.join(link, method, res); os.makedirs(d, exist_ok=True)
        for src in (pngs[0], pngs[0][:-4] + ".json"):
            os.symlink(src, os.path.join(d, os.path.basename(src)))
        n += 1
    print("GATE", method, n, "of", len(ids), flush=True)
sys.exit(1 if bad else 0)
PYEOF
[ $? -eq 0 ] || { echo "GATE failed"; exit 6; }
cd /scratch/09032/saini_2/sca/code/bd42387
run /work/09032/saini_2/vista/library/uv-envs/sca/bin/python scripts/dup_detect.py --subjects results/dup_audit_20261027/subjects_a4k195.json --device cuda --threads 8 --sides 800,1333 --out $E/det --dirs dupfix_bridge_krea=/scratch/09032/saini_2/sca/out/dupfix_krea/dupfix_bridge_krea/4096x4096
/work/09032/saini_2/vista/library/uv-envs/sca/bin/python scripts/dup_rate.py --dets /scratch/09032/saini_2/sca/eval/dup_detect_20261027 $E/det --subjects results/dup_audit_20261027/subjects_a4k195.json --thr 0.35 --kinds person,animal --methods dupfix_bridge_krea --out $E/dup_rates_people.csv | tee -a $E/run.log
/work/09032/saini_2/vista/library/uv-envs/sca/bin/python scripts/dup_rate.py --dets /scratch/09032/saini_2/sca/eval/dup_detect_20261027 $E/det --subjects results/dup_audit_20261027/subjects_a4k195.json --thr 0.35 --methods dupfix_bridge_krea --out $E/dup_rates_any.csv | tee -a $E/run.log
run /work/09032/saini_2/vista/library/uv-envs/sca-metrics/bin/python /work/09032/saini_2/vista/Projects/Exploration/Scale_Covariant_Attention/scripts/eval_extra.py --root $E/root --prompts /scratch/09032/saini_2/constancy_rope/prompts/aesthetic4k_eval.jsonl --out $E/extra --metrics ir,aesthetic,hpsv2,hpsv21,clipiqa,arniqa,is --reference-method dupfix_bridge_krea --device cuda --batch-size 16 --threads 8
run /work/09032/saini_2/vista/library/uv-envs/sca/bin/python /work/09032/saini_2/vista/Projects/Exploration/constancy_rope/scripts/eval.py --root $E/root --prompts /scratch/09032/saini_2/constancy_rope/prompts/aesthetic4k_eval.jsonl --references /scratch/09032/saini_2/constancy_rope/prompts/aesthetic4k_refs.jsonl --reference-method dupfix_bridge_krea --res 4096x4096 --out $E/base --metrics clip,pickscore,musiq,fid,kid,patch_fid,patch_kid --device cuda
mkdir -p $E/corrected_fidp/features && cp -p $E/base/features/*.npz $E/corrected_fidp/features/ && cp -p $E/base/evaluation_cache.json $E/corrected_fidp/ || { echo "feature copy failed"; exit 7; }
(cd /work/09032/saini_2/vista/Projects/Exploration/Scale_Covariant_Attention && WANDB_MODE=disabled run /work/09032/saini_2/vista/library/uv-envs/sca/bin/python repro/evaluate_corrected.py --root $E/root --prompts /scratch/09032/saini_2/constancy_rope/prompts/aesthetic4k_eval.jsonl --references /scratch/09032/saini_2/constancy_rope/prompts/aesthetic4k_refs.jsonl --reference-method dupfix_bridge_krea --reference-clusters images --res 4096x4096 --out $E/corrected_fidp --metrics fid,kid,patch_fid,patch_kid --device cuda --bootstrap 0 --threads 8 --no-wandb)
for pair in dupfix_bridge_krea:sca_krea dupfix_bridge_krea:area sca_krea:area; do a=${pair%%:*}; b=${pair#*:}
  run /work/09032/saini_2/vista/library/uv-envs/sca/bin/python -I /work/09032/saini_2/vista/Projects/Exploration/Scale_Covariant_Attention/scripts/paired_bootstrap.py --method $a --reference $b --draws 2000 --out $E/paired/${a}_vs_${b}.csv $E/extra/extra_per_image.csv $E/base/per_image.csv
done
cp $E/base/summary.csv $R/base_summary.csv && cp $E/extra/extra_summary.csv $R/extra_summary.csv && cp $E/paired/*.csv $R/ && cp $E/dup_rates_*.csv $R/ 2>/dev/null
[ -d $E/corrected_fidp ] && mkdir -p $R/corrected_fidp && cp $E/corrected_fidp/summary.csv $E/corrected_fidp/paired_deltas.csv $R/corrected_fidp/
(cd $R && sha256sum $(find . -name '*.csv' | sort) > SHA256SUMS)
date -u +%FT%TZ > $E/DONE; echo "DONE krea195_dupfix_bridge: $E -> $R"
