#!/bin/bash
# duplication-fix rerun pg: dupfix_bridge --bridge-cells 8 --bridge-k 16
export HF_HOME=/scratch/09032/saini_2/tmp/hf TORCH_HOME=/scratch/09032/saini_2/tmp/torch HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 XDG_CACHE_HOME=/scratch/09032/saini_2/tmp/cache TRITON_CACHE_DIR=/scratch/09032/saini_2/tmp/triton OMP_NUM_THREADS=8
unset CROPE_TRANSFORMER CROPE_ROPE
cd /scratch/09032/saini_2/sca/code/bd42387
/work/09032/saini_2/vista/library/uv-envs/sca/bin/python scripts/sample_progressive.py --prompts /scratch/09032/saini_2/constancy_rope/prompts/aesthetic4k_eval.jsonl --seed 0 --out /scratch/09032/saini_2/sca/out/dupfix_prog/dupfix_bridge_prog/4096x4096 --pi-table /scratch/09032/saini_2/sca/calib/k1_1024.npz --gate-sigma 0.89 --label dupfix_bridge_prog --start 30 --end 35 --bridge-cells 8 --bridge-k 16
