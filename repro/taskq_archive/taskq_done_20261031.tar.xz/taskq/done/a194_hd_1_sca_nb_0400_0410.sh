#!/bin/bash
# SCA_MIN_SECONDS=1440
# Clone of done/h000_sca_nb_4096x4096.sh (SCA on FLUX.1-dev, HRGen-1K); only prompts/start/end changed. Held: release via hold README.
# E4: HRGen-1K SCA
export HF_HOME=/scratch/09032/saini_2/tmp/hf TORCH_HOME=/scratch/09032/saini_2/tmp/torch HF_HUB_OFFLINE=1 XDG_CACHE_HOME=/scratch/09032/saini_2/tmp/cache TRITON_CACHE_DIR=/scratch/09032/saini_2/tmp/triton OMP_NUM_THREADS=8
unset CROPE_TRANSFORMER CROPE_ROPE
cd /scratch/09032/saini_2/sca/code/2d11740
/work/09032/saini_2/vista/library/uv-envs/sca/bin/python scripts/sample.py --method sca --seed 0 --guidance 4.5 --out /scratch/09032/saini_2/sca/out/hrgen/sca_nb/4096x4096 --pi-table /scratch/09032/saini_2/sca/calib/k1_1024.npz --gate-sigma 0.89 --label sca_nb --res 4096x4096 --prompts /scratch/09032/saini_2/sca/hrgen1k.jsonl --start 400 --end 410
