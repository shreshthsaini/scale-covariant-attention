#!/bin/bash
export HF_HOME=/scratch/09032/saini_2/tmp/hf TORCH_HOME=/scratch/09032/saini_2/tmp/torch HF_HUB_OFFLINE=1 XDG_CACHE_HOME=/scratch/09032/saini_2/tmp/cache TRITON_CACHE_DIR=/scratch/09032/saini_2/tmp/triton OMP_NUM_THREADS=8
cd /scratch/09032/saini_2/sca/code/2d11740
/work/09032/saini_2/vista/library/uv-envs/sca/bin/python scripts/sample.py --method sca --res 4096x4096 --prompts /scratch/09032/saini_2/sca/abl50.jsonl --start 20 --end 25 --seed 0 --guidance 4.5 --out /scratch/09032/saini_2/sca/out/abl/abl_route30/4096x4096 --pi-table /scratch/09032/saini_2/sca/calib/k1_1024.npz --gate-sigma 0.89 --band 16 --route 0.30 --label abl_route30
