#!/bin/bash
# SCA_MIN_SECONDS=1200
# Smoke for the 191-prompt extension (sca_prog): runs the exact cloned task body on rows [49, 51) of aesthetic4k_eval.jsonl,
# verifies the new PNG/JSON sidecar (and that existing row 49 is skipped on fingerprint), then publishes this
# code tree's bulk tasks a191_[2]_* from hold_191 to pending. On any failure nothing is published;
# a CUDA OOM from co-tenant GPU processes republishes the smoke to pending (at most 30 times).
set -uo pipefail
Q=/scratch/09032/saini_2/sca/taskq; H=/scratch/09032/saini_2/sca/taskq/hold_191; NAME=a190_smoke_2_sca_prog_049_051.sh; L=/scratch/09032/saini_2/sca/taskq/hold_191/smoke/a190_smoke_2_sca_prog_049_051.attempt.log
oom_requeue(){ grep -q -E 'OutOfMemoryError|CUDA out of memory|CUDA error: out of memory|cudaErrorMemoryAllocation' "$L" || return 1
  n=$(( $(cat $H/retries/$NAME 2>/dev/null || echo 0) + 1 )); echo $n > $H/retries/$NAME
  if [ $n -gt 30 ]; then echo "CUDA OOM retry limit reached (attempt $n); not requeued"; return 1; fi
  cp "$0" "$Q/pending/.$NAME.tmp.$$" && mv -f "$Q/pending/.$NAME.tmp.$$" "$Q/pending/$NAME" && echo "SMOKE CUDA OOM from co-tenant GPU processes: requeued $NAME (attempt $n)"; }
recovered(){ if [ -e "$Q/failed/$NAME" ]; then mkdir -p $Q/recovered/a191_oom; mv "$Q/failed/$NAME" "$Q/recovered/a191_oom/$NAME.$(date +%Y%m%dT%H%M%S)"; fi; }
bash /scratch/09032/saini_2/sca/taskq/hold_191/smoke/a190_smoke_2_sca_prog_049_051.body.sh 2>&1 | tee $L; rc=${PIPESTATUS[0]}
if [ $rc -ne 0 ]; then oom_requeue && exit 75; echo "SMOKE FAILED rc=$rc; nothing published"; exit $rc; fi
python3 -I - /scratch/09032/saini_2/constancy_rope/prompts/aesthetic4k_eval.jsonl /scratch/09032/saini_2/sca/out/prog/sca_prog/4096x4096 0 49 $L <<'PY' || { echo 'SMOKE VERIFY FAILED; nothing published'; exit 5; }
import glob, hashlib, json, sys
prompts, out, seed, first, log = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), open(sys.argv[5]).read()
rows = [json.loads(l) for l in open(prompts) if l.strip()]
for i in range(first, 51):
    pid = rows[i]['id']; png = glob.glob(f'{out}/{pid}_*seed{seed}.png'); js = glob.glob(f'{out}/{pid}_*seed{seed}.json')
    assert len(png) == 1 and len(js) == 1, (i, pid, png, js)
    meta = json.load(open(js[0])); digest = hashlib.sha256(open(png[0], 'rb').read()).hexdigest()
    assert meta.get('complete') is True and meta.get('png_sha256') == digest, (i, pid, 'sidecar')
    assert str(meta['config']['prompt_id']) == pid and int(meta['config']['seed']) == seed, (i, pid, 'config')
    if i == 49: assert f'skip {pid} ' in log, ('row 49 was not skipped', pid)
    print('SMOKE OK', i, pid, png[0], 'seconds', meta.get('seconds'))
PY
n=0; for f in $H/a191_2_*.sh; do [ -e "$f" ] || continue; mv -n "$f" $Q/pending/ && n=$((n+1)); done
echo "SMOKE PASSED; published $n tasks (groups 2)"; recovered
