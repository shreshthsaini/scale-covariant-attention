#!/bin/bash
# E1: UltraImage official code, its own FLUX.1-dev defaults
export HF_HOME=/scratch/09032/saini_2/tmp/hf TORCH_HOME=/scratch/09032/saini_2/tmp/torch HF_HUB_OFFLINE=1 XDG_CACHE_HOME=/scratch/09032/saini_2/tmp/cache TRITON_CACHE_DIR=/scratch/09032/saini_2/tmp/triton OMP_NUM_THREADS=8
unset CROPE_TRANSFORMER CROPE_ROPE
cd /scratch/09032/saini_2/sca/code/PHASE2U
/work/09032/saini_2/vista/library/uv-envs/sca/bin/python scripts/run_ultraimage.py --seed 0 --out /scratch/09032/saini_2/sca/out/main/ultraimage/4096x4096 --res 4096x4096 --prompts /scratch/09032/saini_2/constancy_rope/prompts/aesthetic4k_eval.jsonl --start 0 --end 5
