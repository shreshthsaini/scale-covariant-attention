#!/bin/bash
# SCA_MIN_SECONDS=1500
# Clone of done/j005_area_krea_4096x4096.sh (AReA on FLUX.1-Krea-dev); only prompts/start/end changed. Held: release via hold README.
# E9: AReA on Krea (its own default checkpoint)
export HF_HOME=/scratch/09032/saini_2/tmp/hf TORCH_HOME=/scratch/09032/saini_2/tmp/torch HF_HUB_OFFLINE=1 XDG_CACHE_HOME=/scratch/09032/saini_2/tmp/cache TRITON_CACHE_DIR=/scratch/09032/saini_2/tmp/triton OMP_NUM_THREADS=8
unset CROPE_TRANSFORMER CROPE_ROPE
cd /scratch/09032/saini_2/sca/code/PHASE2
/work/09032/saini_2/vista/library/uv-envs/sca/bin/python scripts/run_area.py --seed 0 --guidance 4.5 --out /scratch/09032/saini_2/sca/out/krea/area/4096x4096 --model krea --res 4096x4096 --prompts /scratch/09032/saini_2/sca/krea_rest95.jsonl --start 80 --end 85
